const playBtn = document.getElementById("playBtn");

let playing = false;

playBtn.addEventListener("click", () => {

  if(playing){
    playBtn.innerHTML = "▶";
    playing = false;
  }else{
    playBtn.innerHTML = "⏸";
    playing = true;
  }

});

const navItems = document.querySelectorAll(".nav");

navItems.forEach(item => {

  item.addEventListener("click", () => {

    navItems.forEach(nav => {
      nav.classList.remove("active");
    });

    item.classList.add("active");

  });

});
